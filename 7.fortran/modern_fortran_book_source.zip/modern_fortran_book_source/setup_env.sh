ml foss/2019a
ml CMake
ml qtcreator
export CC=`which gcc`
export CXX=`which g++`
export FC=`which gfortran`
